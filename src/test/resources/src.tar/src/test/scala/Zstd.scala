package com.github.luben.zstd

import org.scalatest.FlatSpec
import org.scalatest.prop.Checkers
import org.scalacheck.Arbitrary._
import org.scalacheck.Prop._

class ZstdSpec extends FlatSpec with Checkers {
  implicit override val generatorDrivenConfig =
    PropertyCheckConfig(minSize = 0, maxSize = 1024*1024)

  "Zstd" should "should round-trip compression/decompression" in {
    check { input: Array[Byte] =>
      {
        val size        = input.length
        val compressed  = Zstd.compress(input)
        val decompressed= Zstd.decompress(compressed, size)
        input.toSeq == decompressed.toSeq
      }
    }
  }

  it should "be fast for random data" in {
    val rand = new scala.util.Random
    val buff = Array.fill[Byte](1024*1024)(0)
    var nsc = 0.0
    var nsd = 0.0
    var ratio = 0.0
    for (i <- 0 to 1023) {
      rand.nextBytes(buff)
      val start_c     = System.nanoTime
      val compressed  = Zstd.compress(buff)
      nsc += System.nanoTime - start_c
      val start_d     = System.nanoTime
      val size        = Zstd.decompress(buff, compressed)
      nsd += System.nanoTime - start_d
      ratio = 1024.0*1024/compressed.size
    }
    val seconds_c = nsc / (1000 * 1000 * 1000)
    val seconds_d = nsd / (1000 * 1000 * 1000)
    val speed_c   = 1024.0 / seconds_c
    val speed_d   = 1024.0 / seconds_d
    println(s"""
      Uncompressable data
      ===================
      Compression:        ${speed_c.toLong} MB/s
      Decompression:      ${speed_d.toLong} MB/s
      Compression Ratio:  $ratio
    """)
  }

  it should "be fast for highly compressable data" in {
    val rand  = new scala.util.Random
    val buff  = Array.fill[Byte](1024*1024)(0)

    val block = Array.fill[Byte](1024)(0)
    rand.nextBytes(block)
    for (i <- 0 to 1023) {
      Array.copy(block, 0, buff , i * 1024, 1024)
    }
    var nsc = 0.0
    var nsd = 0.0
    var ratio = 0.0
    for (i <- 0 to 1023) {
      val start_c     = System.nanoTime
      val compressed  = Zstd.compress(buff)
      nsc += System.nanoTime - start_c
      val start_d     = System.nanoTime
      val size        = Zstd.decompress(buff, compressed)
      nsd += System.nanoTime - start_d
      ratio = 1024.0*1024/compressed.size
    }
    val seconds_c = nsc / (1000 * 1000 * 1000)
    val seconds_d = nsd / (1000 * 1000 * 1000)
    val speed_c   = 1024.0 / seconds_c
    val speed_d   = 1024.0 / seconds_d
    println(s"""
      Highly compressable data
      ========================
      Compression:        ${speed_c.toLong} MB/s
      Decompression:      ${speed_d.toLong} MB/s
      Compression Ratio:  $ratio
    """)
  }

  it should "be fast for  compressable data" in {
    val buff  = Array.fill[Byte](1024*1024)(0)
    scala.io.Source.fromPath("src.tar").copyToArray(buff,0,        256*1024)
    scala.io.Source.fromPath("src.tar").copyToArray(buff,256*1024, 256*1024)
    scala.io.Source.fromPath("src.tar").copyToArray(buff,512*1024, 256*1024)
    scala.io.Source.fromPath("src.tar").copyToArray(buff,768*1024, 256*1024)
  }

}
